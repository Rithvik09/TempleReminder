

public class Subscription {
	private String Name;
	private String Event;
	private String Email;
	
	public Subscription(String n, String et, String e) {
		this.Name = n;
		this.Event = et;
		this.Email = e;
	}
}
